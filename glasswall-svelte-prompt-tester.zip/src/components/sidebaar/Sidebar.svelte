<script>
	import Button from '../button/Button.svelte';

</script>

<div class="w-full h-[100vh] p-4 flex flex-col gap-4  shadow-xl">
	<Button>Default</Button>
</div>
