export const routes = {
    summaryQualityAnalysis:{
        url:'https://summaryqualityanalysis-jcopwvmitq-uc.a.run.app/',
        method:"POST"
    },
    replyQualityAnalysis:{
        url:'https://replyqualityanalysis-jcopwvmitq-uc.a.run.app/',
        method:"POST"
    },
    suggestionsQualityAnalysis:{
        url:'https://suggestionsqualityanalysis-jcopwvmitq-uc.a.run.app/',
        method:"POST"
    },
    commentsQualityAnalysis:{
        url:'https://commentsqualityanalysis-jcopwvmitq-uc.a.run.app/',
        method:"POST"
    },
}